function requireEnvironmentVariable(name) {
  const value = String(process.env[name] || "").trim();

  if (!value) {
    throw new Error(`Missing environment variable: ${name}`);
  }

  return value;
}

function normalizeIndianPhone(phone) {
  const digits = String(phone || "").replace(/\D/g, "");

  if (digits.length === 10) {
    return `+91${digits}`;
  }

  if (digits.length === 12 && digits.startsWith("91")) {
    return `+${digits}`;
  }

  throw new Error("Invalid customer phone number");
}

function getXmlValue(xml, tagName) {
  const expression = new RegExp(
    `<${tagName}>([\\s\\S]*?)<\\/${tagName}>`,
    "i"
  );

  return String(xml || "").match(expression)?.[1]?.trim() || null;
}

function parseExotelResponse(rawBody) {
  if (!rawBody) {
    return {
      data: {},
      call: null,
    };
  }

  try {
    const data = JSON.parse(rawBody);

    return {
      data,
      call: data.Call || data.call || null,
    };
  } catch {
    const callSid =
      getXmlValue(rawBody, "Sid") ||
      getXmlValue(rawBody, "CallSid");

    const status = getXmlValue(rawBody, "Status");

    return {
      data: {
        raw: rawBody,
      },

      call: callSid
        ? {
            Sid: callSid,
            Status: status,
          }
        : null,
    };
  }
}

function extractExotelError(rawBody, data, statusCode) {
  return (
    data?.RestException?.Message ||
    data?.message ||
    getXmlValue(rawBody, "Message") ||
    `Exotel returned HTTP ${statusCode}`
  );
}

async function startExotelFlowCall(lead) {
  const accountSid = requireEnvironmentVariable(
    "EXOTEL_ACCOUNT_SID"
  );

  const apiKey = requireEnvironmentVariable(
    "EXOTEL_API_KEY"
  );

  const apiToken = requireEnvironmentVariable(
    "EXOTEL_API_TOKEN"
  );

  const subdomain = requireEnvironmentVariable(
    "EXOTEL_SUBDOMAIN"
  );

  const callerId = requireEnvironmentVariable(
    "EXOTEL_CALLER_ID"
  );

  const flowId = requireEnvironmentVariable(
    "EXOTEL_FLOW_ID"
  );

  const publicBackendUrl = requireEnvironmentVariable(
    "PUBLIC_BACKEND_URL"
  ).replace(/\/+$/, "");

  const endpoint =
    `https://${subdomain}` +
    `/v1/Accounts/${accountSid}/Calls/connect.json`;

  const flowUrl =
    `http://my.exotel.com/${accountSid}` +
    `/exoml/start_voice/${flowId}`;

  const statusCallbackUrl = new URL(
  `${publicBackendUrl}/api/webhooks/exotel/status`
);

// This lets the webhook identify the customer,
// even when Exotel's immediate response has no readable SID.
statusCallbackUrl.searchParams.set(
  "leadId",
  String(lead._id)
);

const statusCallback = statusCallbackUrl.toString();

  const requestBody = new URLSearchParams();

  requestBody.set(
    "From",
    normalizeIndianPhone(lead.phone)
  );

  requestBody.set("CallerId", callerId);
  requestBody.set("Url", flowUrl);
  requestBody.set("CallType", "trans");
  requestBody.set("TimeLimit", "180");
  requestBody.set("TimeOut", "30");
  requestBody.set("StatusCallback", statusCallback);
  requestBody.set("CustomField", String(lead._id));

  const encodedCredentials = Buffer.from(
    `${apiKey}:${apiToken}`
  ).toString("base64");

  const response = await fetch(endpoint, {
    method: "POST",

    headers: {
      Authorization: `Basic ${encodedCredentials}`,
      Accept: "application/json",
      "Content-Type":
        "application/x-www-form-urlencoded",
    },

    body: requestBody,
  });

  const rawBody = await response.text();

  const { data, call } = parseExotelResponse(rawBody);

  if (!response.ok) {
    throw new Error(
      extractExotelError(
        rawBody,
        data,
        response.status
      )
    );
  }

  const providerCallId =
    call?.Sid ||
    call?.sid ||
    call?.CallSid ||
    call?.callSid ||
    null;

  const providerCallId =
  call?.Sid ||
  call?.sid ||
  call?.CallSid ||
  call?.callSid ||
  null;

return {
  accepted: true,

  providerCallId,

  providerStatus:
    call?.Status ||
    call?.status ||
    "accepted",

  raw: data,
};
}

module.exports = {
  startExotelFlowCall,
};